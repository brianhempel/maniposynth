module M = Functor.F(X)

let () = assert (M.x = 1)
