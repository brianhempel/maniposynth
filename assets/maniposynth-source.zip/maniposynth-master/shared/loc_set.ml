include Util.SetPlus(Ast.Loc)
